<template>
<div class="home">
      <img alt="Vue logo" src="../assets/Logo.jpg">
    </div>
  <div class="title">
    <p>
      Forecast Your<br>
           Daily Holoscope !
    </p>
  </div>
  <transition>
  <div v-if="showModal">
    <Modal :header="header" :text="text" theme="sale" @close="toggleModal" />
  </div>
  </transition>
  <transition>

  <div v-if="showMatchModal">
    <MatchModal :header="headerMatch" :text="text" theme="sale" @close="toggleMatchModal" />
  </div>

  </transition>
<button @click="toggleModal" class="button button1">Click me to know your Horoscope!</button><br>
<button @click="toggleMatchModal" class="button button1">Click me to forecast your Horoscope match rate with another!</button>
  
</template>

<style>
.title {
  color: aliceblue;
  font-size: 300%;
  font-weight: lighter;
  font-family: 'Brush Script MT', cursive;
}

.button {
  background-color: skyblue; /* Green */
  border: 2px solid rgb(135, 135, 154);
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: rgba(0, 0, 0, 0.5); 
  color: white; 
  border: 2px solid rgb(135, 135, 154);
}
.button1:hover {
  background-color: skyblue;
  color: black;
}

.v-enter-active,
.v-leave-active {
  transition: opacity 1s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}
</style>

<script>
// @ is an alias to /src

import Modal from '@/components/Modal.vue'
import MatchModal from '@/components/MatchModal.vue'

export default {
  
  name: "App",
  components: { Modal, MatchModal },
  data() {
    return {
      header: 'Constellation Identification',
      headerMatch: 'Constellation Match',
      showModal: false,
      showMatchModal: false,
    }
  },
  methods: {
    toggleModal(){
      this.showModal = !this.showModal
    },
    toggleMatchModal(){
      this.showMatchModal = !this.showMatchModal
    }
  }
}
</script>
