<template>
  <div class="product">
    <h1>Product page</h1>
  
  </div>
  <transition>
    <div v-if="showModal">
    <Books :header="header" :text="text" theme="sale" @close="toggleModal" />
  </div>
  </transition>
  <button @click="toggleModal" class="buttonP button1P">Check Feature Constellation Books!</button>
  <div class="row">
  <div class="column">
    <div class="card">
    <img src="../assets/AstroScope01.jpg" alt="Denim Jeans" style="width:100%">
    <h1 class = "productTitle">Product Name</h1>
    <p class="price">$00.00</p>
    <p class="productIntro">Some text about the product.</p>
    <button @click="counter++">Order item :{{ counter }}</button>
    <button @click="counter=0">Reset</button><br>
    </div>
    </div>
  </div>
  <div class="row">
  <div class="column">
    <div class="card">
    <img src="../assets/AstroScope01.jpg" alt="Denim Jeans" style="width:100%">
    <h1 class = "productTitle">Product Name</h1>
    <p class="price">$00.00</p>
    <p class="productIntro">Some text about the product.</p>
    <button @click="counter++">Order item :{{ counter }}</button>
    <button @click="counter=0">Reset</button><br>
    </div>
    </div>
  </div>
  <div class="row">
  <div class="column">
    <div class="card">
    <img src="../assets/AstroScope01.jpg" alt="Denim Jeans" style="width:100%">
    <h1 class = "productTitle">Product Name</h1>
    <p class="price">$00.00</p>
    <p class="productIntro">Some text about the product.</p>
    <button @click="counter++">Order item :{{ counter }}</button>
    <button @click="counter=0">Reset</button><br>
    </div>
    </div>
  </div>
  <div class="row">
  <div class="column">
    <div class="card">
    <img src="../assets/AstroScope01.jpg" alt="Denim Jeans" style="width:100%">
    <h1 class = "productTitle">Product Name</h1>
    <p class="price">$00.00</p>
    <p class="productIntro">Some text about the product.</p>
    <button @click="counter++">Order item :{{ counter }}</button>
    <button @click="counter=0">Reset</button><br>
    </div>
    </div>
  </div>
  <div class="row">
  <div class="column">
    <div class="card">
    <img src="../assets/AstroScope01.jpg" alt="Denim Jeans" style="width:100%">
    <h1 class = "productTitle">Product Name</h1>
    <p class="price">$00.00</p>
    <p class="productIntro">Some text about the product.</p>
    <button @click="counter++">Order item :{{ counter }}</button>
    <button @click="counter=0">Reset</button><br>
    </div>
    </div>
  </div>
  <div class="row">
  <div class="column">
    <div class="card">
    <img src="../assets/AstroScope01.jpg" alt="Denim Jeans" style="width:100%">
    <h1 class = "productTitle">Product Name</h1>
    <p class="price">$00.00</p>
    <p class="productIntro">Some text about the product.</p>
    <button @click="counter++">Order item :{{ counter }}</button>
    <button @click="counter=0">Reset</button><br>
    </div>
    </div>
  </div>
</template>

<style>
.button1P {
  background-color: rgba(0, 0, 0, 0.5); 
  color: white; 
  border: 2px solid rgb(135, 135, 154);
}
.button1P:hover {
  background-color: skyblue;
  color: black;
}
.v-enter-active,
.v-leave-active {
  transition: opacity 1s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}

.buttonP {
        background-color: rgba(0, 0, 0, 0.5);
        border: 2px solid rgb(79, 79, 112);
        color: white;
        padding: 20px 22px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 3px;
        cursor: pointer;
        width: 50%;
        
      }

.row{
  height: 10%;
}

.column {
  float: left;
  width: 31%;
  padding: 0 10px;
}
.productTitle{
  color: white;
}
.productIntro{
  color: burlywood;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(240, 239, 239, 0.9);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: rgba(0, 0, 0, 0.5);
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>

<script>
// @ is an alias to /src

import Books from '@/components/Books.vue'

export default {

  name: "App",
  components: { Books},
  data() {
    return {
      title: 'My first vue app',
      header: 'Feature Constellation Books',
      text: "99%",
      showModal: false,
      counter: 0,
    }
  },
  methods: {
    toggleModal(){
      this.showModal = !this.showModal
    }
  }
}
</script>