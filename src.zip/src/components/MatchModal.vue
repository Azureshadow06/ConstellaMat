<template>
    <div class="backdrop">
        
        <div class="modal" :class="{ sale: theme === 'sale' }">
            <span class="close" @click="closeModal">&times;</span>
            <h1>{{ header }}</h1>
            <span>Horo#1: {{ Selected }}</span>
            <select v-model = "enterHoro1" id="horo1">
                <option disabled value="">please select one</option>
                <option>Taurus</option>
                <option>Leo</option>
                <option>Cancer</option>
                <option>Aries</option>
                <option>Gemini</option>
                <option>Virgo </option>
                <option>Libra</option>
                <option>Scorpius</option>
                <option>Sagittarius</option>
                <option>Capricornus</option>
                <option>Aquarius</option>
                <option>Pisces</option>
            </select>
            and <span>Horo#2: {{ Selected }}</span>
                <select v-model = "enterHoro2" id="horo2">
                <option disabled value="">please select one</option>
                <option>Taurus</option>
                <option>Leo</option>
                <option>Cancer</option>
                <option>Aries</option>
                <option>Gemini</option>
                <option>Virgo </option>
                <option>Libra</option>
                <option>Scorpius</option>
                <option>Sagittarius</option>
                <option>Capricornus</option>
                <option>Aquarius</option>
                <option>Pisces</option>

            </select><br>
            <div :class="{ shake: disabled }">
            <button class="buttonM" type="submit" @click = "ZodiacMatch"> Forecast! </button> <br>
            <p class="result" id="result" align="center"></p>
            </div>

            
            <button class="buttonM" type="submit" @click = "ZodiacComment"> Hints! </button> <br>
            <p class="comments" id="comments" align="center"></p>
        </div>


    </div>
    
    
</template>

<script>
export default {
    props: ['header', 'text', 'theme'],
    data(){
        return {
            disabled: false
        }
    },
    methods: {
        closeModal() {
            this.$emit('close')
        },
        ZodiacMatch(){
            var horo1 = document.getElementById('horo1').value;
            var horo2 = document.getElementById('horo2').value;
            var matchRate;
            var randomNumber = Math.floor(Math.random() * 20) - 10;
            if ((horo1 === "0") && (horo2 === "0")) {
                return document.getElementById("result").innerHTML = "Plz atleast insert sth~";
            }
            else if ((horo1 === "Taurus") && (horo2 === "Taurus")){ 
                matchRate = 80;
            }
            else if((horo1 === "Taurus") && (horo2 === "Leo") || 
            (horo2 === "Taurus") && (horo1 === "Leo")){
                matchRate = 50;
            }
            else if((horo1 === "Taurus") && (horo2 === "Aries") || 
            (horo2 === "Taurus") && (horo1 === "Aries")){
                matchRate = 70;
            }
            else if((horo1 === "Taurus") && (horo2 === "Gemini") || 
            (horo2 === "Taurus") && (horo1 === "Gemini")){
                matchRate = 70;
            }
            else if((horo1 === "Taurus") && (horo2 === "Cancer") || 
            (horo2 === "Taurus") && (horo1 === "Cancer")){
                matchRate = 90;
            }
            
            else{
                this.disabled = true
                setTimeout(() => {
                this.disabled = false
                }, 1500)
                return document.getElementById("result").innerHTML = "Match Rate isnt ready yet \no(╥﹏╥)oI'm sorry~" + horo1 + "&" + horo2;
            }

            return document.getElementById("result").innerHTML = "Match Rate is " + (matchRate + randomNumber) + "% ヾ(✧*▽*)ノ";
        },
        ZodiacComment(){
            var comments;
            var horo1 = document.getElementById('horo1').value;
            var horo2 = document.getElementById('horo2').value;

            if((horo1 === "Taurus") && (horo2 === "Leo") || 
            (horo2 === "Taurus") && (horo1 === "Leo")){
                comments = "The simple and restrained Taurus and the gorgeous Leo have obvious differences in personality, temperament and inner aspects. This feeling may be a force that attracts each other at the beginning. But after a long-term relationship, for the Taurus who wants to work hard to maintain stability and like to be immersed in a warm love nest, the Leo who likes to show off and adore vanity should be a difficult guy to deal with"
            }
            else{
                return document.getElementById("comments").innerHTML = "Hints to this couple still in working (。・＿・。)";
            }
            return document.getElementById("comments").innerHTML = "~✧"+ comments + "✧~";
        },
    },
    
}
</script>

<style>
.shake {
  animation: shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
  transform: translate3d(0, 0, 0);
}

@keyframes shake {
  10%,
  90% {
    transform: translate3d(-1px, 0, 0);
  }

  20%,
  80% {
    transform: translate3d(2px, 0, 0);
  }

  30%,
  50%,
  70% {
    transform: translate3d(-4px, 0, 0);
  }

  40%,
  60% {
    transform: translate3d(4px, 0, 0);
  }
}

.warn{
    color:white;
}
.result{
    color: white; 
}
.close {
  color: rgb(245, 239, 239);
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: rgb(241, 237, 237);
  text-decoration: none;
  cursor: pointer;
}

.buttonM {
  background-color: rgba(0, 0, 0, 0.5); /* Green */
  border: 2px white;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.modal {
    width:800px;
    padding:20px;
    margin:100px auto;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 10px;
}
.backdrop{
    top: 0;
    position: fixed;
    background: rgba(0, 0, 0, 0.5);
    width:100%;
    height: 100%;
}
</style>