<template>
  <nav>
    
    <router-link to="/">Home</router-link> |
    <router-link to="/product">Product</router-link> |
    <router-link to="/about">About</router-link> 
    
  </nav>
  <router-view/>
  
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #cdbdc2;
}
body{
  background: blanchedalmond;
  background-image: url('starlight00.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: skyblue;
}

nav a.router-link-exact-active {
  color: skyblue;
}
</style>
