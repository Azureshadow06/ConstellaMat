<template>
    <div class="backdrop">
        
        <div class="modal" :class="{ sale: theme === 'sale' }">
            <span class="close" @click="closeModal">&times;</span>
            <h1>{{ header }}</h1>
            <form>
                <textarea id="userComments" required="required"></textarea><br><br>
                <b> Enter your name: <input type=text id = userName required="required"> </b><br><br>
                <b> Enter your Email(optional): <input type=text id = userEmail> </b><br><br>
                <button class="buttonM" type="submit"> Submit! </button> <br>
            </form>
                
        </div>
    </div>
    
    
</template>

<script>
export default {
    props: ['header', 'text', 'theme'],
    methods: {
        closeModal() {
            this.$emit('close')
        },
    },
    
}
</script>