<template>
    <div class="backdrop" @click="closeModal">
        <div class="modal" :class="{ sale: theme === 'sale' }">
            <h1>{{ header }}</h1>
        <div class="row">
        <div class="column">
        <div class="card">
        <img src="../assets/ancient-skies.avif" alt="Book#1" style="width:100%">
        </div>  
        </div>

        <div class="column">
        <div class="card">
        <img src="../assets/Book2.jpg" alt="Book#1" style="width:100%">
        </div>  
        </div>

        <div class="column">
        <div class="card">
        <img src="../assets/Book3.jpg" alt="Book#1" style="width:100%">
        </div>  
        </div>
        

        
    </div>
  </div>
    </div>
</template>

<script>
export default {
    props: ['header', 'text', 'theme'],
    methods: {
        closeModal() {
            this.$emit('close')
        }
    }
}
</script>

<style>
.column {
  float: left;
  width: 50%;
  padding: 0 100px;
}
.card {
  box-shadow: 0 4px 8px 0 rgba(240, 239, 239, 0.9);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.modal {
    width:1000px;
    padding:0px;
    margin:100px auto;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 10px;
}
.backdrop{
    top: 0;
    position: fixed;
    background: rgba(0, 0, 0, 0.7);
    width:100%;
    height: 100%;
}
.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>