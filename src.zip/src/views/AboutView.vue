<template>
  <div class="about">
    <h1>About us</h1>
    <p>Creator: Yihe Xiao</p>
    <p class="about">The website is intended for the users who need dating advice and social guide based 
    on user's constellation. The website should be able to provide various information about 
    user's constellation and integrating rate with other constellations based on database</p>
  </div>
  <transition>
  <div v-if="showModal">
    <Comments :header="headerAbout" :text="text" theme="sale" @close="toggleModal" />
  </div>
  </transition>
  <button @click="toggleModal" class="buttonA button1A">Leave your comments here!</button><br>
</template>

<script>
import Comments from '@/components/Comments.vue'
export default {
  
  name: "App",
  components: { Comments },
  data() {
    return {
      headerAbout: 'Write down ur ideas here to improve this website!',
      showModal: false,
    }
  },
  methods: {
    toggleModal(){
      this.showModal = !this.showModal
    },
    toggleMatchModal(){
      this.showMatchModal = !this.showMatchModal
    }
  }
}
</script>

<style>
.about{
  color: azure;
  
}
.button1A {
  background-color: rgba(0, 0, 0, 0.5); 
  color: white; 
  border: 2px solid rgb(135, 135, 154);
}
.button1A:hover {
  background-color: skyblue;
  color: black;
}
.v-enter-active,
.v-leave-active {
  transition: opacity 1s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}
.buttonA {
        background-color: rgba(0, 0, 0, 0.5);
        border: 2px solid white;
        color: white;
        padding: 20px 22px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 3px;
        cursor: pointer;
      }

</style>
