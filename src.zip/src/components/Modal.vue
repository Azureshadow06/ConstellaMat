<template>
    <div class="backdrop">
        
        <div class="modal" :class="{ sale: theme === 'sale' }">
            <span class="close" @click="closeModal">&times;</span>
            <h1>{{ header }}</h1>
            <b> Enter Day of Birth: <input type=number min="1" max="31" id = enterDay> </b><br>
            <b> Enter Month of Birth: <input type=number min="1" max="12" id = enterMonth></b><br>
            <button class="buttonM" type="submit" @click = "checkZodiac"> Done! </button> <br>
            <p class="Age" id="result" align="center"></p> 
        </div>
    </div>
    
    
</template>

<script>
export default {
    props: ['header', 'text', 'theme'],
    methods: {
        closeModal() {
            this.$emit('close')
        },
        checkZodiac(){
            var month = document.getElementById('enterMonth').value;
            var day = document.getElementById('enterDay').value;
            var zodiacSign;
            var zodiacColor;
            if((month==="3")&& (day >=21 && day <=31) || (month==="4")&&(day >=1 && day<=19)){
             zodiacSign= "Passionate Aries";
            }
            else if((month ==="4")&& (day >=20 && day <=30) || (month==="5" || month==="may")&&(day >=1 && day<=20)){
              zodiacSign="Persistent Taurus";
            }  
            else if((month =="5" || month==="may")&& (day >=21 && day <=31) || (month==="6" || month==="june")&&(day >=1 && day<=20)){
             zodiacSign="Witty Gemini";
            }
            else if((month==="6" || month==="june")&& (day >=21 && day <=30) || (month==="7" || month==="july")&&(day >=1 && day<=22)){
             zodiacSign="Emotional Cancer";
            }
            else if((month ==="7" || month==="july")&& (day >=23 && day <=31) || (month==="8" || month==="august" || month==="aug" || month==="Aug")&&(day >=1 && day<=22)){
             zodiacSign="Confident Leo";
            }
            else if((month ==="8" || month==="august")&& (day >=23 && day <=31) || (month==="9" || month==="september" || month==="sept" || month==="Sept")&&(day >=1 && day<=22)){
             zodiacSign="Analytical Virgo";
            }
            else if((month==="9" )&& (day >=23 && day <=31) || (month==="10" || month==="october" || month==="Oct" || month==="oct")&&(day >=1 && day<=22)){
             zodiacSign="Charming Libra";
            }
            else if((month==="10")&& (day >=23 && day <=31) || (month==="11" || month==="november" || month==="Nov" || month==="nov")&&(day >=1 && day<=21)){
             zodiacSign="Passionate Scorpio";
            }
            else if((month==="11" || month==="nov")&& (day >=22 && day <=30) || (month==="12" || month==="december" || month==="Dec" || month==="dec")&&(day >=1 && day<=21)){
             zodiacSign="Adventurous Sagittarius";
            }
            else if((month==="12" || month==="dec")&& (day >=22 && day <=31) || (month==="1" || month==="january" || month==="Jan" || month==="jan")&&(day >=1 && day<=19)){
             zodiacSign="Wise Capricorn";
            }
            else if((month==="1" || month==="january")&& (day >=20 && day <=31) || (month=="2" || month==="february" || month==="feb" || month==="Feb")&&(day >=1 && day<=18)){
             zodiacSign="Inventive Aquarius";
            }
            else if((month==="2")&& (day >=19 && day <=29) || (month=="3" || month=="march" || month=="Mar" || month=="mar")&&(day >=1 && day<=20)){
             zodiacSign="Selfless Pisces";
            }
            
            else{
             alert("At least try to blend in, outer lifeform. _/[○･｀Д´･ ○]_/");
             return document.getElementById("result").innerHTML = "~✧Your Horoscope is OLF✧~";
            }
            return document.getElementById("result").innerHTML = "~✧Your Horoscope is " + zodiacSign + "✧~";
        },
    },
    
}
</script>

<style>
.warn{
    color:white;
}
.Age{
    color: white; 
}
.close {
  color: rgb(245, 239, 239);
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: rgb(241, 237, 237);
  text-decoration: none;
  cursor: pointer;
}

.buttonM {
  background-color: white;
  border: 2px white;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.modal {
    width:800px;
    padding:20px;
    margin:100px auto;
    background: rgba(0, 0, 0, 0.9);
    border-radius: 10px;
}
.backdrop{
    top: 0;
    position: fixed;
    background: rgba(0, 0, 0, 0.9);
    width:100%;
    height: 100%;
}
</style>